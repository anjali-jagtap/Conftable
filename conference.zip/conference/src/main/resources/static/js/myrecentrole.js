let reviewer = document.getElementById("reviewer");
reviewer.onclick = ()=> {
    window.location.href = "/reviewer"
}
let author = document.getElementById("author");
author.onclick = ()=> {
    window.location.href = "/author"
}