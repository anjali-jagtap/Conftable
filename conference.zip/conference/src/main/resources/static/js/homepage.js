localStorage.clear();
sessionStorage.clear();


let Login = document.getElementById("Login");
Login.onclick = ()=> {
    window.location.href = "/login"
}